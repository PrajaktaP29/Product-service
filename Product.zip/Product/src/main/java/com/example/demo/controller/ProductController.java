package com.example.demo.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // User - Get all products
    @GetMapping("/user/getall")
   // @PreAuthorize("hasRole('ROLE_USER')")  // Ensure only 'USER' can access this
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    // User - Get product by ID
    @GetMapping("/user/getproduct/id/{id}")
  // Ensure only 'USER' can access this
    public Optional<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }
    
    @GetMapping("/user/getproduct/name/{name}")
   
    public List<Product> searchProducts(@PathVariable String name) {
        return productService.searchProductsByName(name);
    }

    // Admin - Add or Update a product
    @PostMapping("/admin/add")
    // Ensure only 'ADMIN' can access this
    public String addOrUpdateProduct(@RequestBody Product product) {
    	Product savedProduct = productService.saveProduct(product);  
        return "Product added successfully with ID: " + savedProduct.getId();  

        //return productService.saveProduct(product);
    }
    
    
    // Admin - Update a product
    @PutMapping("/admin/update/{id}")
  // Ensure only 'ADMIN' can access this
    public Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        return productService.updateProduct(id, updatedProduct);
    }

    // Admin - Delete a product
    @DeleteMapping("/admin/delete/{id}")
    // Ensure only 'ADMIN' can access this
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }
}
