package com.example.demo;

import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import javax.crypto.SecretKey;
import java.util.Base64;

@Component
public class JwtService implements GlobalFilter {

    @org.springframework.beans.factory.annotation.Value("${jwt.secret}")
    String tokenSecret;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, org.springframework.cloud.gateway.filter.GatewayFilterChain chain) {
       
    	// Get the Authorization header from the request
        String authorizationHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        
        // Check if the authorization header exists and starts with "Bearer "
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return onError(exchange, "No authorization header", HttpStatus.UNAUTHORIZED);
        }

        // Extract the token by removing the "Bearer " part
        String token = authorizationHeader.substring(7);
        
        // Validate the token and extract the userId (subject)
        String userId = isValidToken(token);
        
        if (userId == null || userId.isEmpty()) {
            return onError(exchange, "Invalid or expired token", HttpStatus.UNAUTHORIZED);
        }

        // Add user info (userId) to the request headers
        exchange = exchange.mutate()
                .request(r -> r.header("userinfo", userId))
                .build();

        // Continue with the filter chain
        return chain.filter(exchange);
    }

    // Error handling method
    private Mono<Void> onError(ServerWebExchange exchange, String errorMessage, HttpStatus status) {
        exchange.getResponse().setStatusCode(status);
        return exchange.getResponse().setComplete();
    }

    // Token validation method
    private String isValidToken(String token) {
        try {
            // Decode the secret key and create a SecretKey instance
            byte[] secretKeyBytes = Base64.getEncoder().encode(tokenSecret.getBytes());
            SecretKey secretKey = Keys.hmacShaKeyFor(secretKeyBytes);

            // Use the older method: Jwts.parser()
            JwtParser parser = (JwtParser) Jwts.parser()
                    .setSigningKey(secretKey);  // Set the signing key

            // Parse the JWT and extract the subject (userId)
            return parser.parseClaimsJws(token).getBody().getSubject();
        } catch (Exception e) {
            // Return null if the token is invalid or expired
            return null;
        }
    }
}